# OROLOGIO DIGITALE

Progetto Android Studio per un widget orologio digitale personalizzabile.

## Compilazione
Aprire la cartella del progetto in Android Studio e attendere la sincronizzazione Gradle. Poi scegliere **Build > Build APK(s)**.

È disponibile anche la compilazione automatica tramite GitHub Actions (workflow in `.github/workflows/android.yml`).

## Funzioni incluse nella prima versione
- Widget Android nativo ridimensionabile
- Ore e minuti, con secondi opzionali
- Data opzionale
- Dimensione testo regolabile
- Colore testo tramite codice HEX
- Sfondo trasparente o colorato
- Anteprima e salvataggio impostazioni

Nota: questa è una prima versione funzionante di base. Le impostazioni sono condivise tra i widget; la personalizzazione indipendente di ogni singolo widget e ulteriori controlli grafici sono previste per una versione successiva.
