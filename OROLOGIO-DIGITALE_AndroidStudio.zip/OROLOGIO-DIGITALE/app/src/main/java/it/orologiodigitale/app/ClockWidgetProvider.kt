package it.orologiodigitale.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import android.graphics.Color
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClockWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateAppWidget(context, manager, it) }
    }

    companion object {
        fun updateAppWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val p = context.getSharedPreferences("clock_settings", Context.MODE_PRIVATE)
            val showSeconds = p.getBoolean("seconds", false)
            val showDate = p.getBoolean("date", true)
            val transparent = p.getBoolean("transparent", true)
            val color = try { Color.parseColor(p.getString("textColor", "#FFFFFF")) } catch (_: Exception) { Color.WHITE }
            val size = p.getInt("textSize", 34)
            val pattern = if (showSeconds) "HH:mm:ss" else "HH:mm"
            val time = SimpleDateFormat(pattern, Locale.getDefault()).format(Date())
            val date = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date())
            val views = RemoteViews(context.packageName, R.layout.clock_widget)
            views.setTextViewText(R.id.clock_time, time)
            views.setTextViewText(R.id.clock_date, date)
            views.setViewVisibility(R.id.clock_date, if (showDate) android.view.View.VISIBLE else android.view.View.GONE)
            views.setTextColor(R.id.clock_time, color)
            views.setTextColor(R.id.clock_date, color)
            views.setTextViewTextSize(R.id.clock_time, android.util.TypedValue.COMPLEX_UNIT_SP, size.toFloat())
            views.setInt(R.id.widget_root, "setBackgroundResource", if (transparent) android.R.color.transparent else R.drawable.widget_background)
            manager.updateAppWidget(id, views)
        }
    }
}
