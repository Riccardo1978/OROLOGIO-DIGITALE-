package it.orologiodigitale.app

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("clock_settings", Context.MODE_PRIVATE) }
    private lateinit var preview: TextView
    private lateinit var seconds: CheckBox
    private lateinit var date: CheckBox
    private lateinit var transparent: CheckBox
    private lateinit var colorInput: EditText
    private lateinit var sizeSeek: SeekBar
    private lateinit var sizeLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(12, 24, 45))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.WHITE)
            setPadding(0, 10, 0, 8)
        }
        root.addView(label("OROLOGIO DIGITALE", 24f))
        root.addView(label("Personalizza il widget della schermata Home"))
        preview = TextView(this).apply {
            text = "12:45"; textSize = 42f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setPadding(12, 24, 12, 24)
        }
        root.addView(preview, LinearLayout.LayoutParams(-1, -2))
        seconds = CheckBox(this).apply { text = "Mostra i secondi"; setTextColor(Color.WHITE); isChecked = prefs.getBoolean("seconds", false) }
        date = CheckBox(this).apply { text = "Mostra la data"; setTextColor(Color.WHITE); isChecked = prefs.getBoolean("date", true) }
        transparent = CheckBox(this).apply { text = "Sfondo trasparente"; setTextColor(Color.WHITE); isChecked = prefs.getBoolean("transparent", true) }
        root.addView(seconds); root.addView(date); root.addView(transparent)
        root.addView(label("Colore testo (HEX, ad esempio #FFFFFF)"))
        colorInput = EditText(this).apply {
            setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(0xFFB0BEC5.toInt())
            hint = "#FFFFFF"; setText(prefs.getString("textColor", "#FFFFFF"))
        }
        root.addView(colorInput)
        sizeLabel = label("Dimensione orologio")
        root.addView(sizeLabel)
        sizeSeek = SeekBar(this).apply {
            max = 48; progress = (prefs.getInt("textSize", 34) - 18).coerceIn(0, 48)
        }
        root.addView(sizeSeek)
        val save = Button(this).apply {
            text = "SALVA IMPOSTAZIONI"
            setOnClickListener { saveSettings() }
        }
        root.addView(save)
        val help = label("Per aggiungere il widget: tieni premuto sulla schermata Home, scegli Widget e seleziona Orologio digitale.")
        root.addView(help)
        setContentView(ScrollView(this).apply { addView(root) })
        updatePreview()
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { sizeLabel.text = "Dimensione orologio: ${p + 18} sp"; updatePreview() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        seconds.setOnCheckedChangeListener { _, _ -> updatePreview() }
        date.setOnCheckedChangeListener { _, _ -> updatePreview() }
    }

    private fun chosenColor(): Int = try { Color.parseColor(colorInput.text.toString().trim()) } catch (_: Exception) { Color.WHITE }

    private fun updatePreview() {
        if (!::preview.isInitialized) return
        val fmt = if (seconds.isChecked) "HH:mm:ss" else "HH:mm"
        val now = java.text.SimpleDateFormat(fmt, java.util.Locale.getDefault()).format(java.util.Date())
        preview.text = now + if (date.isChecked) "\n" + java.text.SimpleDateFormat("EEE, d MMM", java.util.Locale.getDefault()).format(java.util.Date()) else ""
        preview.textSize = (sizeSeek.progress + 18).toFloat()
        preview.setTextColor(chosenColor())
        preview.setBackgroundColor(if (transparent.isChecked) Color.TRANSPARENT else 0xFF263B5A.toInt())
    }

    private fun saveSettings() {
        val color = try { Color.parseColor(colorInput.text.toString().trim()).let { colorInput.text.toString().trim() } } catch (_: Exception) { "#FFFFFF" }
        prefs.edit().putBoolean("seconds", seconds.isChecked)
            .putBoolean("date", date.isChecked)
            .putBoolean("transparent", transparent.isChecked)
            .putString("textColor", color)
            .putInt("textSize", sizeSeek.progress + 18).apply()
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, ClockWidgetProvider::class.java))
        ids.forEach { ClockWidgetProvider.updateAppWidget(this, manager, it) }
        Toast.makeText(this, "Impostazioni salvate", Toast.LENGTH_SHORT).show()
        updatePreview()
    }
}
